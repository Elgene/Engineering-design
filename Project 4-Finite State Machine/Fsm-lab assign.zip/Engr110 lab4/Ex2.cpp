/*Example FSM code*/
/*Reads string from keyboard*/
/*
Runs FSM on each character of the 
string (calling function Pro) 
until # character is found
*/
#include <iostream>
#include <string>

using namespace std;

string state;  // current FSM state

/*Describes an FSM with four states: s0, s1,s2 and s3 */
/* s3 is an accepting state*/
/*returns 1 if FSM is in accepting state*/
int ProcessChar(char in_char){
int accept = 0;

if (state == "s0"){
   if (in_char == 'c'){state="s1";}
   else { state="s0";}
}
else if (state == "s1"){
   if (in_char == 'a'){ state= "s2";}
   else if(in_char == 'c') { state= "s1";}
   else {state = "s0";}
}	
else if (state == "s2"){
  if (in_char == 't'){ state = "s3";}	
  else if (in_char == 'c'){state = "s1";} // exercise 2
  else { state = "s0"; }
}
else if (state == "s3") {  //exercise 2 
  if ( in_char == 'c'){state ="s1";} 
  else{state ="s0";}
}
 if (state == "s3") {accept =1;}
 cout<<"in_char="<<in_char<<" accept="<<accept<<endl;
 return accept;

}


int main(){
 string input;
 cout<<"enter input string:";
 cin>>input;
 cout<<"Input is "<<input<<" state is"<<state<<endl;
 unsigned int count = 0;
 int string_accepted = 0;
 state = "s0"; //starting state
 count = 0;
 while ( 1 ){ 
   if (input.at(count) == '#') break; // run until #
   string_accepted = ProcessChar(input.at(count));
   count++;
 }  
 cout<<" accepted = "<<string_accepted<<endl;
} 

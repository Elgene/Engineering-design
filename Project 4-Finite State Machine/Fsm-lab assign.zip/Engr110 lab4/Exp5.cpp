/*Example FSM code*/
/*Reads string from keyboard*/
/*
Runs FSM on each character of the 
string (calling function Pro) 
until # character is found
*/
#include <iostream>
#include <string>
#include <vector>

using namespace std;

string state;  // current FSM state
vector<int> token; 
string str ;

/*Describes an FSM with four states: s0, s1,s2 and s3 */
/* s3 is an accepting state*/
/*returns 1 if FSM is in accepting state*/
int ProcessChar(char in_char){
int accept = 0;

//cout<<"before:"<<state<<"  in= "<<in_char<<endl;
if (state == "s0"){
   if (in_char== ','||in_char== '#'){
	    state = "s1";
	    //cout<<"Comma encountered"<<str;
	    token.push_back(stoi(str));
	    cout<<stoi(str)<<endl;
	    str.clear();
	   }
  else{
	  str.push_back(in_char);
	  //cout<<"Added"<<str<<endl;
	  state= "s0";
  }

}
else if (state == "s1"){
   if (in_char== ','){
	   state="s1";
   } 
   else{
	   state="s0";
	   str.push_back(in_char);
	    }

 
}
//cout<<"after:"<<state<<endl;

 return accept; 
}


int main(){
 string input;
 cout<<"enter input string:";
 cin>>input;
 cout<<"Input is "<<input<<" state is"<<state<<endl;
 unsigned int count = 0;
 int string_accepted = 0;
 state = "s0"; //starting state
 count = 0;
 while ( count < input.size() ){ 
  //if (input.at(count) == '#') break; // run until #
   string_accepted = ProcessChar(input.at(count));
   count++;
 }  
 
 
 
} 


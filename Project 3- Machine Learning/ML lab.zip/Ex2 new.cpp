#include <iostream>
#include <fstream> // for logging
#include <math.h>


using namespace std;


double sigmoid(double x){
    return 1.0 / (1.0 + exp(-x));
}

/*class to describe Neural net composed pf one neuron*/ 
class NN1 {
   private:
      double* w;   // weights
      double bias;
      double t[4] = {1,1,1,0}; // Training Dataset, Truth Table, target
      double* y;  // outputs for all rows of TT
      double xt[4][2] = {{0.0,0.0},{0.0,1.0},{1.0,0.0},{1.0,1.0}}; // training inputs  
      double error;     // error - squared difference between neuron output and target
      ofstream outputFile; // for logging purpose
      double dBias;
      double dW[];
  public:
      NN1();
      void ForwardProp();
      void Plot();
      void UserInput();
       void GlobalSearch();
       void CalculateGradient();
      void GradientStep();
      void GradientSearch();
 };

NN1::NN1(){  //constructor, opens file to store pictures
     w = new double[2];  // 2 weights
     y = new double[4];  // 4 rows(entries) in dataset
     outputFile.open("ex2plot.txt"); 
}
  

// calculate neuron output and error
// for all rows of truth table
// for current values of bias and weights
void NN1::ForwardProp(){
      error = 0.0;
      for (int irow = 0 ; irow < 4 ; irow++){
           y[irow] = sigmoid (bias + xt[irow][0]*w[0] + xt[irow][1]*w[1]);
           error = error + pow(y[irow] -t[irow],2.0);
      }
  }
  
// produce file with error()
void NN1::Plot(){
    bias = 1.0;  // just a guess
    // cycles for all reasonable values of weights
    for (w[0] = -10; w[0] <=10; w[0]=w[0]+0.5){
       for (w[1]=-10;  w[1]<=10; w[1]=w[1]+0.5){
          ForwardProp();
          cout<<"bias="<<bias<<"  w0="<<w[0]<<"  w1="<<w[1]<<" error="<<error<<endl;
          outputFile<<w[0]<<" "<<w[1]<<" "<<error<<endl;
       }
     }
  }
  
void NN1::UserInput(){ 
	cout << "Enter the w0 value : ";
	cin>>w[0];
	cout << "Enter the w1 value : ";
	cin>>w[1]; 
	cout << "Enter the bias value : ";
	cin>>bias; 
	ForwardProp();
    cout<<"bias="<<bias<<"  w0="<<w[0]<<"  w1="<<w[1]<<" error="<<error<<endl;
 }
  
 void NN1::GlobalSearch(){
   
    // cycles for all reasonable values of weights
   
  double minBias;
    double minW0;
    double minW1;
    double errorMin = 1000;
    struct timespec ts_start;
    struct timespec ts_end;
    clock_gettime(CLOCK_MONOTONIC, &ts_start);
    for(bias=0; bias< 30 ; bias++ ){
    for (w[0] = -10; w[0] <=10; w[0]=w[0]+0.5){
       for (w[1]=-10;  w[1]<=10; w[1]=w[1]+0.5){
          ForwardProp();
          if(error <errorMin){
	 errorMin= error;
	 minBias= bias;
	 minW0 = w[0];
	 minW1 =w[1];
         double nstep = 0;
         while(nstep<100){
          //calculateGradient();
          // gradientStep();
           nstep++;
            cout<<"step: "<<nstep<<endl; 
             cout<<"error: "<<error<<endl; 
            
         }                  
         }
        }        	  
       }
     }
     clock_gettime(CLOCK_MONOTONIC,&ts_end);
     long elapsed =(ts_end.tv_nsec-ts_start.tv_nsec );
       cout<<"bias="<<minBias<<"  w0="<<minW0<<"  w1= "<<minW1<<" error= "<<errorMin<<"time taken in nanoseconds "<<elapsed<<endl;
       outputFile<<w[0]<<" "<<w[1]<<" "<<error<<endl;
  }
 void NN1::CalculateGradient(){
	double step = 0.1; 
	ForwardProp();
	double e0 = error;
	bias = bias + step;
	ForwardProp();
	double e1 = error;
	bias = bias - step;
	dBias = (e1 - e0) / step;
	
	w[0] += step;
	ForwardProp();
	e1 = error;
	dW[0] = (e1 - e0) / step;
	w[0] -= step;
	
	w[1] += step;
	ForwardProp();
	e1 = error;
	dW[1] = (e1 - e0) / step;
	w[1] -= step;
	}




void NN1::GradientStep(){
	double learning_rate = 30.0;
	bias = bias - learning_rate * dBias;
	w[0] = w[0] - learning_rate * dW[0];
	w[1] = w[1] - learning_rate * dW[1];
}


void NN1::GradientSearch(){
	int nStep = 0;
	ForwardProp();
	while(nStep<400){
	CalculateGradient();
	GradientStep();
	nStep++;
	cout<<error<<endl;
	outputFile<<nStep<<" "<<error<<endl;
	}
}
int main(){
     NN1 nn1;
     nn1.Plot();
     nn1.UserInput();   
     nn1.GlobalSearch();
     nn1.CalculateGradient();
    nn1.GradientStep();
    nn1.GradientSearch();
    
     
 } 
   

